// TUTORIAL 9: Show current day/time and update every second
function showTime() {
    const now = new Date();
    const timeString = now.toLocaleString();
    document.getElementById("currentTime").textContent = "Current Time: " + timeString;
}
setInterval(showTime, 1000); // TUTORIAL 9: Delay command with interval

// TUTORIAL 9: Alert message
alert("Welcome! Please fill out the form below.");

// TUTORIAL 9: Math method
let x = 5.678;
let rounded = Math.round(x);
console.log("Rounded number: " + rounded);

// TUTORIAL 9: Convert number to text
let num = 42;
let numText = num.toString();
console.log("Number to text: " + numText);

// TUTORIAL 9: Countdown Function
let countdown = 10;
let timer = setInterval(function () {
    if (countdown === 0) {
        clearInterval(timer);
        console.log("Countdown complete!");
    } else {
        console.log("Countdown: " + countdown);
        countdown--;
    }
}, 1000);
